package com.example.lpgTest.repository;

import com.example.lpgTest.model.Category;
import com.example.lpgTest.model.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

    /*@Query(value = "SELECT * FROM Product p JOIN Category c " +
            "ON p.category_id = c.id " +
            "WHERE p.category_id = ?",
            nativeQuery = true)
    Page<Product> findAllByCategory(int categoryId, Pageable pageable);*/

    Page<Product> findAllByCategory(Category category, Pageable pageable);

    Page<Product> findByOrderByName(Pageable pageable);

}
