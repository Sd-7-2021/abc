package com.example.lpgTest.controller;

import com.example.lpgTest.model.Category;
import com.example.lpgTest.model.Product;
import com.example.lpgTest.service.CategoryService;
import com.example.lpgTest.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.*;


@Controller
public class ProductController {

    private static final int DEFAULT_PAGE_SIZE = 5;
    private final ProductService productService;
    private final CategoryService categoryService;

    @Autowired
    public ProductController(ProductService productService, CategoryService categoryService) {
        this.productService = productService;
        this.categoryService = categoryService;
    }

    @GetMapping(path = "/products")
    public ModelAndView getProducts(@PageableDefault(size = DEFAULT_PAGE_SIZE) Pageable pageable) {

        Page<Product> productPage = productService.findAll(pageable);
        List<Product> products = new ArrayList<>();
        productPage.forEach(product -> products.add(product));
        List<Category> categories = categoryService.getAll();
        return getModelAndView(pageable, productPage, products, categories, 0);
    }

    @GetMapping(path = "/products/category")
    public ModelAndView getProductsByCategory(@RequestParam("category") Category category,
                                              @PageableDefault(size = DEFAULT_PAGE_SIZE) Pageable pageable) {

        Page<Product> productPage = productService.findProductsByCategory(category, pageable);
        List<Product> products = new ArrayList<>();
        productPage.forEach(product -> products.add(product));
        List<Category> categories = categoryService.getAll();
        return getModelAndView(pageable, productPage, products, categories, category.getId());
    }

    @PostMapping(path = "/products/remove/{id}")
    public String deleteById(@PathVariable("id") Integer id) {
        Optional<Product> productToDelete = productService.findById(id);
        if (productToDelete.isPresent()) {
            productService.deleteById(id);
        }
        return "redirect:/products";
    }

    @GetMapping(path = "/products/new")
    public ModelAndView getAddForm(Model model) {
        List<Category> categories = categoryService.getAll();
        ModelAndView mv = new ModelAndView();
        mv.setViewName("edit");
        model.addAttribute("categories", categories);
        model.addAttribute("product", new Product());
        mv.addObject(model);
        return mv;
    }

    @PostMapping(path = "/products/save")
    public String save(@Valid @ModelAttribute(name = "product") Product product,
                       BindingResult result, Model model) {
        if (result.hasErrors()) {
            //TODO: better handling.
            model.addAttribute("errors", result.toString());
            return "error";
        }
        productService.save(product);
        return "redirect:/products";
    }

    @GetMapping(path = "/products/{id}")
    public ModelAndView getById(@PathVariable("id") Integer id) {
        Optional<Product> product = productService.findById(id);
        ModelAndView mv = new ModelAndView();
        if (product.isPresent()) {
            List<Category> categories = categoryService.getAll();
            mv.setViewName("edit");
            mv.addObject("categories", categories);
            mv.addObject("product", product.get());
        }
        else {
            mv.setViewName("error");
            mv.addObject("errors", "Product not found");
        }
        return mv;
    }

    private ModelAndView getModelAndView(Pageable pageable, Page<Product> productPage,
                                         List<Product> products, List<Category> categories, int selectedCategory) {
        Map params = new HashMap<String, Object>();
        params.put("sortDirection", pageable.getSort().stream()
                .findFirst()
                .orElse(new Sort.Order(Sort.Direction.ASC, "Name"))
                .getDirection());
        params.put("selectedCategory", selectedCategory);
        params.put("products", products);
        params.put("categories", categories);
        params.put("totalPages", productPage.getTotalPages());
        // Indexed - 0
        params.put("currentPage", productPage.getNumber() + 1);
        params.put("selectedPageResults", pageable.getPageSize());
        return new ModelAndView("products", params);
    }
}
