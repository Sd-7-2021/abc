package com.example.lpgTest.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;

@Entity
@Table (name = "product")
public class Product implements Serializable {
    // TODO: Use GenerationType.SEQUENCE - requires database sequence
    private @Id @GeneratedValue(strategy=GenerationType.IDENTITY) Integer id;
    @NotNull (message = "Please provide product name.")
    private String name;
    @NotNull (message = "Please provide product description.")
    private String description;
    @NotNull (message = "Please provide product category.")
    private @ManyToOne Category category;
    private Date creationDate = new Date();
    private Date updateDate = new Date();
    @NotNull (message = "Please provide product purchased date.")
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date purchasedDate;
    @Transient
    private String purchasedDateAsString;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Date getPurchasedDate() {
        return purchasedDate;
    }

    public void setPurchasedDate(Date purchasedDate) {
        this.purchasedDate = purchasedDate;
        setPurchasedDateAsString(getPurchasedDateAsString());
    }

    public String  getPurchasedDateAsString() {
        if (purchasedDateAsString == null && purchasedDate != null) {
            //Simple formatting implementation
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            setPurchasedDateAsString(dateFormat.format(purchasedDate));
        }
        return purchasedDateAsString;
    }

    public void setPurchasedDateAsString(String purchasedDateAsString) {
        this.purchasedDateAsString = purchasedDateAsString;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return id == product.id && name.equals(product.name) && description.equals(product.description)
                && category.equals(product.category) && Objects.equals(creationDate, product.creationDate)
                && Objects.equals(updateDate, product.updateDate)
                && Objects.equals(purchasedDate, product.purchasedDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, description, category, creationDate, updateDate, purchasedDate);
    }
}
