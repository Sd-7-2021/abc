package com.example.lpgTest.service;

import com.example.lpgTest.repository.CategoryRepository;
import com.example.lpgTest.model.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CategoryService {
    private final CategoryRepository categoryRepository;

    @Autowired
    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public List<Category> getAll() {
        List<Category> categories = new ArrayList<Category>();
        categoryRepository.findAll().forEach(category -> categories.add(category));
        return categories;
    }
}
