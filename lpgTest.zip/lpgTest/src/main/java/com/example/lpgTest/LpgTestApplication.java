package com.example.lpgTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LpgTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(LpgTestApplication.class, args);
	}

}
