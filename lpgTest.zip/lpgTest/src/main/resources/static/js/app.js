var query = function (queryObj) {
    var initPath = '/products?';
    if (queryObj.selectedCategory != null) {
        initPath = '/products/category?category=' + queryObj.selectedCategory +"&";
    }
    window.location = encodeURI(initPath + 'sort=' + queryObj.colName
      + "," + queryObj.direction
      + "&size=" + queryObj.resultsPerPage
      + "&page=" + queryObj.pageNumber);
}

var bindColumnSorting = function () {
    $('.sort').on('click', function () {
       var queryObj = {};
       queryObj.colName = $(this).attr('data-column-name');
       var direction = $(this).attr('data-sort-direction');
       queryObj.selectedCategory = $("#category").val();
       queryObj.resultsPerPage = $("#page-results").val();

       if (direction == "ASC") {
         queryObj.direction = "DESC"
       }
       else {
         queryObj.direction = "ASC"
       }
       query(queryObj);
     });
}

var bindPageLinkClick = function () {
    $(".page-link").on('click', function () {
         var queryObj = {};
         queryObj.colName = $("#name-column").attr('data-column-name');
         queryObj.direction = $("#name-column").attr('data-sort-direction');
         var pageNumber = $(this).attr("data-page");
         queryObj.selectedCategory = $("#category").val();
         queryObj.resultsPerPage = $("#page-results").val();
         pageNumber = pageNumber - 1;
         queryObj.pageNumber = pageNumber;
         query(queryObj);
     });
}

var bindPageResultsSizeChange = function () {
    $("#page-results").on('change', function () {
          var queryObj = {};
          queryObj.colName = $("#name-column").attr('data-column-name');
          queryObj.direction = $("#name-column").attr('data-sort-direction');
          queryObj.selectedCategory = $("#category").val();
          queryObj.resultsPerPage = $("#page-results").val();
          query(queryObj);
      });
}

// On page load
$(function (){
    $("#page-results").val($("#page-results").attr("data-selected-page-size"));
    bindColumnSorting();
    bindPageLinkClick();
    bindPageResultsSizeChange();
});


