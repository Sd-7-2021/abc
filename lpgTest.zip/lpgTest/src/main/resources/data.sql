INSERT INTO category (category_name) VALUES
('Kitchen'),
('Power Tools'),
('Furniture'),
('Electric'),
('Washroom'),
('Textiles'),
('Misc.');

INSERT INTO product (name, description, category_id, creation_date, update_date, purchased_date) VALUES
('Knife Set','A set of knives in all shapes and sizes.','1','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01'),
('Plate Rack','A storage solution for plates.','1','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01'),
('Microwave','Cook food quick with this handy microwave.','1','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01'),
('Juicer','When life gives you lemons, make lemonade.','1','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01'),
('Meat Hooks','A butchers meat hook.','1','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01'),
('Cabinet Knobs','Make sure you can open your cabinets.','1','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01'),
('Frying Pans','Cook up a storm with this non stick frying pan.','1','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01'),
('Power Drill','A drill, but with an electric motor.','2','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01'),
('Jack Hammer','Demolish old concrete and removing pavement, it does it all1','2','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01','2020-09-20 00:01:00+01')
;