# Getting Started
The application is build using Spring Boot with in memory database H2 as the persistence layer. Persistence is implemented using the JPA repository. The frontend is generated using the Apache Freemarker template engine supported by JQuery. This is currently a multiple page application. Improvement would be to use a more dynamic frontend framework such as React JS.

## Installation
This is a Spring Boot application built using Maven. You can build a jar file and run it from the command line or open it in an IDE and run it.
You can then access application on: http://localhost:8080/
Initial data bootstrapped.

## User Stories covered
<ul>
    <li>As a user, I want to see all products</li>
    <li>As a user, I want to be able to sort the products by Name</li>
    <li>As a user, I want to be able to filter by Category</li>
    <li>As a user, I want to page results (5,10 and 20)</li>
    <li>As a user, I want to be able to add a new product</li>
    <li>As a user, I want to be able to update a product</li>
    <li>As a user, I want to be able to delete a product</li>
</ul>
Along with the above, details of how these stories interact is also covered to a certain extent

## Technology Stack
<ul>
    <li>Java8</li>
    <li>Spring Boot using Spring MVC with JPA and H2 DB (2.5.2)</li>
    <li>Apache Freemarker template engine (2.3.4)</li>
    <li>JQuery (3.5.1)</li>
    <li>Bootstrap (5.0.2)</li>
</ul>

## ToDo
<ul>
    <li>Pending challenge of the purchasedDate validation, for which I was thinking of
        using a custom validator, however the above issue took more time, hence this was not done.</li>
    <li>Error/Exception handling needs to be implemented for form validation failures,
        currently there is a catch all error page.</li>
    <li>Automated Tests.</li>
</ul>